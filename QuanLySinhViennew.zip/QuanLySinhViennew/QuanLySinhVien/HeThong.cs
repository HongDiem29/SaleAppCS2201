﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien
{
    //mã hoá mật khẩu
    public class HeThong
    {

        public static string TENDANGNHAP = "";
        public static string LOAITAIKHOAN = "";

       

    }
}
