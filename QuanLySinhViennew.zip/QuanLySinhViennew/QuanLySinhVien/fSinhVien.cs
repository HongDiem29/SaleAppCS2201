﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class fSinhVien : Form
    {
        private SqlConnection cn;
        private SqlDataAdapter adapter;
        private DataSet dataset;
        private DataTable datatable;
        public fSinhVien()
        {
            InitializeComponent();
            string cnStr = "Data Source=ADMIN-PC;Initial Catalog=db_QLSV;Integrated Security=True";
            cn = new SqlConnection(cnStr);
        }

        private void fSinhVien_Load(object sender, EventArgs e)
        {

         /*   if (HeThong.LOAITAIKHOAN != "Quản trị")
                btnQuanLy.Visible = false;
            else
                btnQuanLy.Visible = true;*/

            LoadData();
        }

        private void LoadData()
        {
             string sql = "SELECT * FROM SinhVien";
              adapter = new SqlDataAdapter(sql, cn);
              dataset = new DataSet();
              adapter.Fill(dataset);
              dgvSinhVien.DataSource = dataset.Tables[0];
        }


        private void quảnLýKhoaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           fQuanLyKhoa f = new fQuanLyKhoa();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void quảnLýLớpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fQuanLyLop f = new fQuanLyLop();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void quảnLýCốVấnHọcTậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
           fCoVanHocTap f = new fCoVanHocTap();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void quảnLýMônHọcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fQuanLyMonHoc f = new fQuanLyMonHoc();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void quảnLýĐiểmToolStripMenuItem_Click(object sender, EventArgs e)
        {
           fQuanLyDiem f = new fQuanLyDiem();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void quảnLýTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fQuanLyTaiKhoan f = new fQuanLyTaiKhoan();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void thôngTinChiTiếtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new fThongTinChiTiet().ShowDialog();
        }

        private void đổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new fDoiMatKhau().ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
