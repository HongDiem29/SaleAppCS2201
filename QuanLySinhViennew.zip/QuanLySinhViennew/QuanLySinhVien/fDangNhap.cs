﻿using BusinessLayer;
using QuanLySinhVien.BLL;
using QuanLySinhVien.GUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TranferObject;
using BusinessLayer;


namespace QuanLySinhVien
{
    public partial class fDangNhap : Form
    {

        public fDangNhap()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {

            string tendangnhap = txbTenDangNhap.Text;
            string matkhau = txbMatKhau.Text;
                         
            Account acc = new Account(tendangnhap, matkhau);

            bool b = false;
            try
            {
                b = new LoginBL().fDangNhap(acc);
                fSinhVien f = new fSinhVien();
                this.Hide();
                f.ShowDialog();
                this.Show();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (b)
            {
                this.DialogResult = DialogResult.OK;    
            }
            else
            {

                string msg = "Ten đăng nhập và mật khẩu không đúng!";
                DialogResult result = MessageBox.Show(msg, "fDangNhap", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                if(result == DialogResult.Cancel)
                {
                    Application.Exit();
                }
                else
                {
                    txbTenDangNhap.Focus();
                }
            }
        }
        
    }
}
