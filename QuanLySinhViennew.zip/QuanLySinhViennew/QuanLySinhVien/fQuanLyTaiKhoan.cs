﻿using BusinessLayer;
using QuanLySinhVien.BLL;
using QuanLySinhVien.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QuanLySinhVien
{

   public partial class fQuanLyTaiKhoan : Form
   {
       private SqlConnection cn;
       private SqlDataAdapter adapter;
       private DataSet dataset;
       /*private DataTable dataTable;*/
    public fQuanLyTaiKhoan()
        {
            InitializeComponent();
            string cnStr = "Data Source=ADMIN-PC;Initial Catalog=db_QLSV;Integrated Security=True";
            cn = new SqlConnection(cnStr);
        }


        private void LoadData()
        {
            string sql = "SELECT * FROM TaiKhoan";
            adapter = new SqlDataAdapter(sql, cn);
            dataset = new DataSet();
            adapter.Fill(dataset);
            dgvTaiKhoan.DataSource = dataset.Tables[0];
        }

        private void fQuanLyTaiKhoan_Load(object sender, EventArgs e)
        {
            LoadData();
            btnLamMoi.PerformClick();
            cmbLoaiTaiKhoan.SelectedIndex = 0;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {

            /* string tendangnhap = txbTenDangNhap.Text.Trim();
             string matkhau = txbMatKhau.Text.Trim();
             string loaiTK = cmbLoaiTaiKhoan.SelectedItem.ToString();

             // Kiểm tra tính hợp lệ của các thông tin nhập vào
             if (tendangnhap.Length > 0 && matkhau.Length >= 6 && loaiTK.Length > 0)
             {
                 try
                 {
                     // Mở kết nối với cơ sở dữ liệu
                     cn.Open();

                     // Câu lệnh SQL để thêm tài khoản
                     string sql = "INSERT INTO TaiKhoan (TenDangNhap, MatKhau, LoaiTaiKhoan) VALUES (@TenDangNhap, @MatKhau, @LoaiTaiKhoan)";

                     // Tạo đối tượng SqlCommand và truyền câu lệnh SQL cùng với kết nối
                     SqlCommand cmd = new SqlCommand(sql, cn);

                     // Thêm tham số vào câu lệnh SQL
                     cmd.Parameters.AddWithValue("@TenDangNhap", tendangnhap);
                     cmd.Parameters.AddWithValue("@MatKhau", matkhau);
                     cmd.Parameters.AddWithValue("@LoaiTaiKhoan", loaiTK);

                     // Thực thi câu lệnh SQL
                     int rowsAffected = cmd.ExecuteNonQuery();

                     // Kiểm tra xem có dòng nào bị ảnh hưởng (thêm thành công)
                     if (rowsAffected > 0)
                     {
                         MessageBox.Show("Thêm tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                         LoadData();  // Tải lại dữ liệu vào DataGridView
                     }
                     else
                     {
                         MessageBox.Show("Có lỗi xảy ra khi thêm tài khoản.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     }
                 }
                 catch (Exception ex)
                 {
                     // Xử lý lỗi
                     MessageBox.Show("Tên dăng nhập không được trùng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 }
                 finally
                 {
                     cn.Close();  // Đảm bảo đóng kết nối sau khi thực hiện
                 }
             }
             else
             {
                 MessageBox.Show("Vui lòng điền đầy đủ thông tin và đảm bảo mật khẩu có ít nhất 6 ký tự.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
             }*/



            string tendangnhap = txbTenDangNhap.Text.Trim();
             string matkhau = txbMatKhau.Text.Trim();
             string loaiTK = cmbLoaiTaiKhoan.SelectedItem.ToString();

             if (tendangnhap.Length > 0 && matkhau.Length >= 6 && loaiTK.Length > 0)
             {

                 try
                 {                  
                    if (LoginBL.Instance.Them(tendangnhap, matkhau, loaiTK) == true)
                       btnLamMoi.PerformClick();  //bấm lại                                      
                 }
                 catch
                 {
                     MessageBox.Show("Tên dăng nhập không được trùng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                 }
             }
             else
             {
                 MessageBox.Show("Mật khẩu không được dưới 6 ký tự", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

             }
             


        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dgvTaiKhoan.CurrentRow.Cells[0].Value.ToString());
            string ten = dgvTaiKhoan.CurrentRow.Cells[1].Value.ToString().Trim();

            if (MessageBox.Show("Bạn có muốn xoá tài khoản " + ten + " không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    if (LoginBL.Instance.Xoa(id) == true)
                        btnLamMoi.PerformClick();
                }
                catch
                {
                    MessageBox.Show("Phát sinh lỗi khi xoá :(( ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            }
        }
        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void dgvTaiKhoan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          txbID.Text = dgvTaiKhoan.CurrentRow.Cells[0].Value.ToString().Trim();
          txbTenDangNhap.Text = dgvTaiKhoan.CurrentRow.Cells[1].Value.ToString().Trim();
           cmbLoaiTaiKhoan.SelectedItem = dgvTaiKhoan.CurrentRow.Cells[3].Value.ToString().Trim();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txbID.Text);
            string tendangnhap = txbTenDangNhap.Text.Trim();
            string matkhau = txbMatKhau.Text.Trim();
            string loaiTK = cmbLoaiTaiKhoan.SelectedItem.ToString();

            if (tendangnhap.Length > 0 && loaiTK.Length > 0)
            {
                try
                {
                    //Không sửa mật khẩu
                    if(matkhau.Length == 0)
                    {
                        if (LoginBL.Instance.KhongSuaMatKhau(tendangnhap, loaiTK, id) == true)
                            btnLamMoi.PerformClick();  //bấm lại
                    }
                    //Sửa mật khẩu
                    else
                    {
                        if (LoginBL.Instance.SuaHet(tendangnhap, matkhau, loaiTK, id) == true)
                            btnLamMoi.PerformClick();  //bấm lại
                    }
                }
                catch
                {
                    MessageBox.Show("Tên dăng nhập không được trùng ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Mật khẩu không được dưới 6 ký tự ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

        }
    }
    
}
