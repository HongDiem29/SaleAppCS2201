﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using TranferObject;


namespace BusinessLayer
{
    public class LoginBL
    {
        private static LoginBL instance;
        public static LoginBL Instance
        {
            get { if (instance == null) instance = new LoginBL(); return instance; }
            private set => instance = value;
        }

        public bool fDangNhap(Account acc)
        {
             DataTable dulieu = LoginDL.Instance.DangNhap(acc.Username, acc.Password);

            if (dulieu.Rows.Count == 0)
            {
                return false;
            }
            else
            {
                Account.USERNAME = acc.Username;
                Account.LOAITAIKHOAN = dulieu.Rows[0]["LoaiTaiKhoan"].ToString().Trim();
                
            }
            return true;
        }      
        public bool Them(string ten, string matkhau, string loai)
        {            
            return LoginDL.Instance.Them(ten, matkhau, loai);
        }

        public bool SuaHet(string ten, string matkhau, string loai, int id)
        {
            return LoginDL.Instance.Sua_Het(ten, matkhau, loai, id);
        }

        public bool KhongSuaMatKhau(string ten, string loai, int id)
        {
            return LoginDL.Instance.KhongSuaMatKhau(ten, loai, id);
        }

        public bool Xoa(int id)
        {
            return LoginDL.Instance.Xoa(id);
        }

        public bool DoiMatKhau(string tendangnhap, string matkhaumoi, string matkhaucu)
        {
            return LoginDL.Instance.DoiMatKhau(tendangnhap, matkhaumoi, matkhaucu);
        }

    }
}

