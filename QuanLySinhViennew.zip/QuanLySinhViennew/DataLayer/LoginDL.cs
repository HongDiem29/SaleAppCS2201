﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TranferObject;
using System.Data;
using System.Data.SqlClient;
using QuanLySinhVien.DAL;

namespace DataLayer
{
    public class LoginDL : DataProvider
    {
        private static LoginDL instance;
        public static LoginDL Instance
        {
            get { if (instance == null) instance = new LoginDL(); return instance; }
            private set => instance = value;
        }

        private SqlConnection cn;
        public bool fDangNhap(Account acc)
        {
            string sql = "SELECT COUNT(TenDangNhap) FROM TaiKhoan WHERE TenDangNhap ='" + acc.Username + "' AND MatKhau = '" + acc.Password + "'";
            try
            {
                return ((int)MyExecuteScalar(sql, CommandType.Text) > 0);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       

        public bool Them(string ten, string matkhau, string loai)
        {
            string sql = "INSERT INTO TaiKhoan(TenDangNhap, MatKhau, LoaiTaiKhoan) VALUES( @TenDangNhap , @MatKhau , @LoaiTaiKhoan )";
            return KetNoi.Instance.ExcuteNonQuery(sql, new object[] { ten, matkhau, loai });
        }

        public bool Sua_Het(string ten, string matkhau, string loai, int id)
        {
            string sql = "UPDATE TaiKhoan SET TenDangNhap = @TenDangNhap , MatKhau = @MatKhau , LoaiTaiKhoan = @LoaiTaiKhoan WHERE id = @id";
            return KetNoi.Instance.ExcuteNonQuery(sql, new object[] { ten, matkhau, loai, id });
        }

        public bool KhongSuaMatKhau(string ten, string loai, int id)
        {
            string sql = "UPDATE TaiKhoan SET TenDangNhap = @TenDangNhap , LoaiTaiKhoan = @LoaiTaiKhoan WHERE id = @id";
            return KetNoi.Instance.ExcuteNonQuery(sql, new object[] { ten, loai, id });
        }

        public bool Xoa(int id)
        {
            string sql = "DELETE FROM TaiKhoan WHERE id = @id";
            return KetNoi.Instance.ExcuteNonQuery(sql, new object[] { id });
        }


        public bool DoiMatKhau(string ten, string matkhaumoi, string matkhaucu)
        {
            string sql = "UPDATE TaiKhoan SET MatKhau = @MatKhauMoi WHERE TenDangNhap = @TenDangNhap AND MatKhau = @MatKhauCu";
            return KetNoi.Instance.ExcuteNonQuery(sql, new object[] { matkhaumoi, ten, matkhaucu });
        }

        public DataTable DangNhap(string tendangnhap, string matkhau)
        {
            string sql = "SELECT * FROM TaiKhoan WHERE TenDangNhap = @TenDangNhap and MatKhau = @MatKhau";
            return KetNoi.Instance.ExcuteQuery(sql, new object[] { tendangnhap, matkhau });
        }



    }
}
