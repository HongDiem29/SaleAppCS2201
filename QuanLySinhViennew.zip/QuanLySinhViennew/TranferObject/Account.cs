﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TranferObject
{
    public class Account
    {

        public static string USERNAME = "";
        public static string LOAITAIKHOAN = "";
        public string Username { get; set; }
        public string Password { get; set; }


        public Account(string tendangnhap = "", string matkhau = "")
        {
            this.Username = tendangnhap;
            this.Password = matkhau;
        }
    }

}


