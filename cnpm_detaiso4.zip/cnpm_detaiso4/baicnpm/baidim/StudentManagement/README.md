# quanlyhocsinh
Student management website by using Python-flask, Mysql, javascript

The steps run the :
1. Cloning the project
2. Openning the project
3. Reinstalling the libraries: pip install -r requirements.txt in terminal(command prompt)
4. Checking database in models.py and creating an empty database
5. Run models.py
6. Run index.py and testing
